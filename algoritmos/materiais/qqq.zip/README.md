# algoritmos
Questões de Algoritmo
